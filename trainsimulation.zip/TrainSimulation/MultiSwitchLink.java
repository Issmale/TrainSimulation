

import api.Point;
import api.PointPair;

/**
 * 
 * @author Issmale Bekri
 *
 */
public class MultiSwitchLink extends AbstractLink {
	
	/**
	 * connection of tracks
	 */
	private PointPair[] connections;
	
	/**
	 * constructor for MultiSwitchLink
	 * @param declared final connections 
	 */
    public MultiSwitchLink(final PointPair[] connections) {
    	 this.connections = connections;
    }
    
    /**
     * switches connections
     * @param  declared final pointPair 
     * @param  declared final index 
     */
    public void switchConnection(final PointPair pointPair, final int index) {
    	 connections[index] = pointPair;
        
    }
    
    /**
     * gets the connected points
     * @param declared point 
     * @return returns the point
     */
    @Override
    public Point getConnectedPoint(final Point point) {
    	for (int i = 0; i < connections.length; i++) {
            PointPair connection = connections[i];
            Point pointA = connection.getPointA();
            Point pointB = connection.getPointB();
            if (pointA.equals(point)) {
                return pointB;
            } else if (pointB.equals(point)) {
                return pointA;
            }
        }
        return null;
    }
    /**
     * returns the number of paths
     */
    @Override
    public int getNumPaths() {
    	return connections.length;
    }
}