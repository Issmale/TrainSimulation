

import api.Point;

/**
 * 
 * @author Issmale Bekri
 *
 */
public class CouplingLink extends AbstractLink
{	
	/**
	 *  first end point
	 */
    private Point firstEndPoint;
    /**
     *  second end point
     */
    private Point SecondEndPoint;
    
    /**
     * constuctor 
     * @param endpoint1 first end point
     * @param endpoint2 second end point
     */
    public CouplingLink(final Point endpoint1, final Point endpoint2) {
        firstEndPoint = endpoint1;
        SecondEndPoint = endpoint2;
    }
    
    /**
     * returns the points connected to the given point if they are equal. Returns null
	 * if no point is connected to the given point.
     * @param point 
     */
    @Override
    public Point getConnectedPoint(final Point point) {
    	if (point.equals(firstEndPoint)) {
            return SecondEndPoint;
        } 
    	else if (point.equals(SecondEndPoint)) {
            return firstEndPoint;
        }
    	else {
    		return null;
    	}
    }
    /**
	 * returns the num of paths
	 */
	@Override
    public int getNumPaths() {
		return 2;
    }
}