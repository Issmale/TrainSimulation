

import api.Point;

/**
 * @author Issmale Bekri
 */
public class TurnLink extends AbstractLink {
	
	/**
	 * endpoint 1
	 */
	private Point endpoint1;
	
	/**
	 * endpoint 2
	 */
    private Point endpoint2;
    
    /**
     * endpoint 3
     */
    private Point endPoint3;
    
    /**
     * boolean variable to keep track of turn
     */
    private boolean isTurn = false;
    
    /**
     * constructor for class
     * @param endpointA 
     * @param endpointB 
     * @param endpointC 
     */
	public TurnLink(Point endpointA, Point endpointB, Point endpointC) {
		endpoint1 = endpointA;
        endpoint2 = endpointB;
        endPoint3 = endpointC;
	}

	/**
	 * gets connected points
	 * @param declared final point 
	 */
	@Override
    public Point getConnectedPoint(Point point) {
		
		
		
    	if (point.equals(endpoint1)) {
            return endPoint3;
        } 
    	else if (point.equals(endpoint2)) {
            return endpoint1;
        } 
    	else if (point.equals(endPoint3)) {
    		if (!isTurn) {
            	return endpoint1; 
            }
    		else {
            	return endpoint2;
            }
        }
        return null;
        
    }
	/*
	 * method to set turn 
	 */
	protected void setTurn(boolean turn) {
		isTurn = turn;
	}
	
	/**
	 * return the num paths
	 */
	@Override
	public int getNumPaths() {
		return 3;
	}
}
