

import api.Point;
import api.PointPair;

/**
 * 
 * @author Issmale Bekri
 * 
 */
public class MultiFixedLink extends AbstractLink{
	
	/**
	 * connection of tracks
	 */
    private PointPair[] connections;
    
    /**
     * Constructor 
     * @param decalared final connections
     */
    public MultiFixedLink(final PointPair[] connections) {
        this.connections = connections;
    }
    
    /**
     * protected method for getting connections
     * @param declared final connectionIndex
     * @return returns the connections based on the index
     */
    protected PointPair getConnection(final int connectionIndex) {
        return connections[connectionIndex];
    }
    
    /**
     * method for getting connected points
     * @param declared final point
     * @return returns otherPoint
     */
    @Override
    public Point getConnectedPoint(final Point point) {
    	Point otherPoint = null;
        for (int i = 0; i < connections.length; i++) {
            PointPair connection = connections[i];
            if (point.equals(connection.getPointA())) {
                otherPoint = connection.getPointB();
            } 
            else if (point.equals(connection.getPointB())) {
                otherPoint = connection.getPointA();
            }
        }
        return otherPoint;
    }
    /**
     * returns the num of paths
     */
    @Override
    public int getNumPaths() {
    	return connections.length;
    }
}