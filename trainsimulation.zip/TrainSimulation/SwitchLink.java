

import api.Point;

/**
 * @author Issmale Bekri
 */
public class SwitchLink extends AbstractLink {
	
    /**
     * endpoint 1
     */
    private Point endpoint1;
    
    /**
     * endpoint 2
     */
    private Point endpoint2;
    
    /**
     * endpoint 3
     */
    private Point endpoint3;
    
    /**
	 * variable that tracks turn
	 */
    private boolean isTurn;

    /**
     * constructor for switchlink
     * @param declared final endpointA 
     * @param declared final endpointB 
     * @param declared final endpointC 
     */
    public SwitchLink(final Point endpointA, final Point endpointB, final Point endpointC) {
    	endpoint1 = endpointA;
    	endpoint2 = endpointB;
    	endpoint3 = endpointC;
    }
    
    /**
     * method that sets turns
     * @param declared final turn 
     */
    public void setTurn(final boolean turn) {
        this.isTurn = turn;
    }
    
    /**
     * gets connected points
     * @param declared final point 
     * @return returns endpoint 1 2 or 3
     */
    @Override
    public Point getConnectedPoint(Point point) {
    	if (point.equals(endpoint1)) {
            if (isTurn) {
                return endpoint3;
            } 
            else {
                return endpoint2;
            }
        } 
    	else if (point.equals(endpoint2) || point.equals(endpoint3)) {
            return endpoint1;
        }
        return null;
    }
}