

import api.Point;
import api.PositionVector;
import api.Crossable;
import api.Path;

/**
 * 
 * 
 * @author Issmale Bekri
 *
 */
public abstract class AbstractLink implements Crossable {
	
	/**
	 * Gets the point that is connected to the given point by the link. Returns null
	 * if no point is connected to the given point.
	 * @param declared final point
	 * @return the point
	 */
	@Override
    public Point getConnectedPoint(final Point point) {
		if(point != null) {
			return point;
		}
		else {
			return point;
		}
	}
	/**
	 * This method is called by the simulation to indicate a train has entered the
	 * crossing.
	 */
	@Override
    public void trainEnteredCrossing() {
    }
    
	/**
	 * This method is called by the simulation to indicate a train has exited the
	 * crossing.
	 */
	@Override
    public void trainExitedCrossing() {
    }
    
	/**
	 * Gets the total number of paths connected by the link
	 * @return number paths
	 */
	@Override
    public int getNumPaths() {
		return 0;
    }
    
	/**
	 * shifts points
	 * @param declared final positionVector 
	 */
	@Override
    public void shiftPoints(final PositionVector positionVector) {
		final Point point1 = getConnectedPoint(positionVector.getPointB());
	    final int pointIndex = point1.getPointIndex();
	    final Path path = point1.getPath();
	    Point point2;
	    if (pointIndex == 0) {
	        point2 = path.getPointByIndex(1);
	    } else {
	        point2 = path.getPointByIndex(pointIndex - 1);
	    }
	    positionVector.setPointA(point1);
	    positionVector.setPointB(point2);
	}
}