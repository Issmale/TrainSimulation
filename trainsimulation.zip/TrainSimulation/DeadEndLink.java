

import api.Point;
import api.PositionVector;

/**
 * 
 * @author Issmale Bekri
 * 
 */
public class DeadEndLink extends AbstractLink {
	
	
	/**
	 * method shifting points
	 * @param declared  final positionVector 
	 */
	@Override
    public void shiftPoints(final PositionVector positionVector) {
    }
    
	/**
	 * returns null
	 * @param declared final point 
	 */
    @Override
    public Point getConnectedPoint(final Point point) {
    	
        return null;
    }
    
    /**
     * This method is called by the simulation to indicate a train has entered the
	 * crossing.
     */
    @Override
    public void trainEnteredCrossing() {
    }
    
    /**
     * This method is called by the simulation to indicate a train has exited the
	 * crossing.
     */
    @Override
    public void trainExitedCrossing() {
    }
    
    /**
     *  Gets the total number of paths connected by the link.
     *  @return the total number of paths
     */
    @Override
    public int getNumPaths() {
        return 1;
    }
}