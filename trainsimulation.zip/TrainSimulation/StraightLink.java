

import api.Point;

/**
 * 
 * @author Issmale Bekri
 * 
 */
public class StraightLink extends AbstractLink {
	
	/**
	 * endpoint 1
	 */
    private Point endPoint1;
    
    /**
     * endpoint 2
     */
    private Point endPoint2;
    
    /**
     * endpoint 3
     */
    private Point endPoint3;
    
    /**
     * Constuctor for straightlink
     * @param declared final endpointA 
     * @param declared final endpointB 
     * @param declared final endpointC 
     */

    public StraightLink(final Point endpointA, final Point endpointB, final Point endpointC) {
		// TODO Auto-generated constructor stub
    	endPoint1 = endpointA;
        endPoint2 = endpointB;
        endPoint3 = endpointC;
	}

	/**
     * gets connected points
     * @param declared final point 
     * @return endPoint 1 or endPoint 2
     */
    @Override
    public Point getConnectedPoint(final Point point) {
        if (point == endPoint1) {
            return endPoint2;
        }
        else if (point == endPoint2) {
            return endPoint1;
        }
        return endPoint1;
    }
    /**
     * returns the num of paths
     */
    @Override
    public int getNumPaths() {
    	return 3;
    }
}